FOOD LOVERS WEBSITE

1. Extract this ZIP file.
2. Open the food-lovers-website folder.
3. Upload index.html and the images folder to your GitHub repository.
4. In GitHub, open Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Choose branch main and folder /(root), then Save.

Keep the images folder beside index.html. Do not rename the image files.
