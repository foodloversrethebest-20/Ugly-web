UGLY FOOD LOVERS WEBSITE

Upload index.html and the complete images folder to your GitHub repository.
Keep the images folder beside index.html.
Then enable GitHub Pages from Settings > Pages > Deploy from a branch > main > /(root).
